ELAPACK
elapack.com
tina@elapack.com
Free custom dieline: elapack.com/contact

Native editable Illustrator template. No PSD included.
Units: mm. Print at actual size (100%).
Magenta: cut. Cyan: crease. Green: 3 mm bleed.
Reference template only. Factory review and white sample required.
Magnetic rigid box wrap corner relief must be finalized by the factory.
